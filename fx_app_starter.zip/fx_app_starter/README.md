# No2: 為替換算アプリ（CUI版）スターターパック

- API: ExchangeRate-API (https://www.exchangerate-api.com/)
- 4パターン対応：JPY↔KRW、JPY↔SGD
- 実行方法：`pip install requests` → `python exchange_app.py`

APIキーは環境変数 `EXCHANGE_API_KEY` に設定するか、起動時に入力します。
