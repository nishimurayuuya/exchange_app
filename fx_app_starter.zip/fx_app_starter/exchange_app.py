import os, sys, json, requests

BASE_URL = "https://v6.exchangerate-api.com/v6/{key}/latest/{base}"

def ensure_key():
    key = os.getenv("13127c3f9793b95a6f4cfbb3")
    if not key:
        key = input("APIキー（EXCHANGE_API_KEY）が未設定です。ここに貼ってEnter：").strip()
    if not key:
        print("APIキーが空です。終了します。"); sys.exit(1)
    return key

def fetch_rate(key, base, to):
    url = BASE_URL.format(key=key, base=base)
    print(f"[GET] {url}")
    r = requests.get(url, timeout=20); r.raise_for_status()
    data = r.json()
    if data.get("result") != "success":
        raise RuntimeError(data.get("error-type", "unknown-error"))
    return data["conversion_rates"][to]

def ask_float(prompt):
    while True:
        s = input(prompt).strip()
        try:
            return float(s)
        except ValueError:
            print("数値で入力してください。")

MENU = """
=== 為替換算ツール（CUI）===
1) 円→ウォン (JPY->KRW)
2) 円→シンガポールドル (JPY->SGD)
3) ウォン→円 (KRW->JPY)
4) シンガポールドル→円 (SGD->JPY)
0) 終了
選択: """

def main():
    key = ensure_key()
    while True:
        sel = input(MENU).strip()
        if sel == "0":
            print("終了します。"); return
        if sel not in {"1","2","3","4"}:
            print("メニュー番号を入力してください。"); continue

        if sel == "1":
            base, to = "JPY", "KRW"
        elif sel == "2":
            base, to = "JPY", "SGD"
        elif sel == "3":
            base, to = "KRW", "JPY"
        else:
            base, to = "SGD", "JPY"

        amt = ask_float(f"金額を入力 ({base}): ")
        try:
            rate = fetch_rate(key, base, to)
            result = amt * rate
            print(f"{amt:,.2f} {base} = {result:,.2f} {to}  (1 {base} = {rate:.6f} {to})")
            os.makedirs("output", exist_ok=True)
            with open("output/last_result.txt", "w", encoding="utf-8") as f:
                f.write(f"pair={base}->{to}\namount={amt}\nrate={rate}\nconverted={result}\n")
            print("→ output/last_result.txt に保存しました。")
        except Exception as e:
            print("換算に失敗：", e)

if __name__ == "__main__":
    main()
